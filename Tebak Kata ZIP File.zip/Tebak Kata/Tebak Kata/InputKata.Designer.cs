﻿namespace Tebak_Kata
{
    partial class InputKata
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_Word1 = new System.Windows.Forms.Label();
            this.lbl_Word2 = new System.Windows.Forms.Label();
            this.lbl_Word3 = new System.Windows.Forms.Label();
            this.lbl_Word4 = new System.Windows.Forms.Label();
            this.lbl_Word5 = new System.Windows.Forms.Label();
            this.tBox_Kata1 = new System.Windows.Forms.TextBox();
            this.tBox_Kata2 = new System.Windows.Forms.TextBox();
            this.tBox_Kata3 = new System.Windows.Forms.TextBox();
            this.tBox_Kata4 = new System.Windows.Forms.TextBox();
            this.tBox_Kata5 = new System.Windows.Forms.TextBox();
            this.btn_Play = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_Word1
            // 
            this.lbl_Word1.AutoSize = true;
            this.lbl_Word1.Location = new System.Drawing.Point(70, 58);
            this.lbl_Word1.Name = "lbl_Word1";
            this.lbl_Word1.Size = new System.Drawing.Size(87, 25);
            this.lbl_Word1.TabIndex = 0;
            this.lbl_Word1.Text = "Word 1:";
            // 
            // lbl_Word2
            // 
            this.lbl_Word2.AutoSize = true;
            this.lbl_Word2.Location = new System.Drawing.Point(70, 99);
            this.lbl_Word2.Name = "lbl_Word2";
            this.lbl_Word2.Size = new System.Drawing.Size(87, 25);
            this.lbl_Word2.TabIndex = 1;
            this.lbl_Word2.Text = "Word 2:";
            // 
            // lbl_Word3
            // 
            this.lbl_Word3.AutoSize = true;
            this.lbl_Word3.Location = new System.Drawing.Point(70, 139);
            this.lbl_Word3.Name = "lbl_Word3";
            this.lbl_Word3.Size = new System.Drawing.Size(87, 25);
            this.lbl_Word3.TabIndex = 2;
            this.lbl_Word3.Text = "Word 3:";
            // 
            // lbl_Word4
            // 
            this.lbl_Word4.AutoSize = true;
            this.lbl_Word4.Location = new System.Drawing.Point(70, 184);
            this.lbl_Word4.Name = "lbl_Word4";
            this.lbl_Word4.Size = new System.Drawing.Size(87, 25);
            this.lbl_Word4.TabIndex = 3;
            this.lbl_Word4.Text = "Word 4:";
            // 
            // lbl_Word5
            // 
            this.lbl_Word5.AutoSize = true;
            this.lbl_Word5.Location = new System.Drawing.Point(70, 228);
            this.lbl_Word5.Name = "lbl_Word5";
            this.lbl_Word5.Size = new System.Drawing.Size(87, 25);
            this.lbl_Word5.TabIndex = 4;
            this.lbl_Word5.Text = "Word 5:";
            // 
            // tBox_Kata1
            // 
            this.tBox_Kata1.Location = new System.Drawing.Point(164, 57);
            this.tBox_Kata1.Name = "tBox_Kata1";
            this.tBox_Kata1.Size = new System.Drawing.Size(214, 31);
            this.tBox_Kata1.TabIndex = 5;
            // 
            // tBox_Kata2
            // 
            this.tBox_Kata2.Location = new System.Drawing.Point(163, 96);
            this.tBox_Kata2.Name = "tBox_Kata2";
            this.tBox_Kata2.Size = new System.Drawing.Size(215, 31);
            this.tBox_Kata2.TabIndex = 6;
            // 
            // tBox_Kata3
            // 
            this.tBox_Kata3.Location = new System.Drawing.Point(163, 136);
            this.tBox_Kata3.Name = "tBox_Kata3";
            this.tBox_Kata3.Size = new System.Drawing.Size(215, 31);
            this.tBox_Kata3.TabIndex = 7;
            // 
            // tBox_Kata4
            // 
            this.tBox_Kata4.Location = new System.Drawing.Point(163, 181);
            this.tBox_Kata4.Name = "tBox_Kata4";
            this.tBox_Kata4.Size = new System.Drawing.Size(215, 31);
            this.tBox_Kata4.TabIndex = 8;
            // 
            // tBox_Kata5
            // 
            this.tBox_Kata5.Location = new System.Drawing.Point(164, 225);
            this.tBox_Kata5.Name = "tBox_Kata5";
            this.tBox_Kata5.Size = new System.Drawing.Size(214, 31);
            this.tBox_Kata5.TabIndex = 9;
            // 
            // btn_Play
            // 
            this.btn_Play.Location = new System.Drawing.Point(181, 271);
            this.btn_Play.Name = "btn_Play";
            this.btn_Play.Size = new System.Drawing.Size(178, 38);
            this.btn_Play.TabIndex = 10;
            this.btn_Play.Text = "Play!";
            this.btn_Play.UseVisualStyleBackColor = true;
            this.btn_Play.Click += new System.EventHandler(this.btn_Play_Click);
            // 
            // InputKata
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1269, 796);
            this.Controls.Add(this.btn_Play);
            this.Controls.Add(this.tBox_Kata5);
            this.Controls.Add(this.tBox_Kata4);
            this.Controls.Add(this.tBox_Kata3);
            this.Controls.Add(this.tBox_Kata2);
            this.Controls.Add(this.tBox_Kata1);
            this.Controls.Add(this.lbl_Word5);
            this.Controls.Add(this.lbl_Word4);
            this.Controls.Add(this.lbl_Word3);
            this.Controls.Add(this.lbl_Word2);
            this.Controls.Add(this.lbl_Word1);
            this.Name = "InputKata";
            this.Text = "Form2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_Word1;
        private System.Windows.Forms.Label lbl_Word2;
        private System.Windows.Forms.Label lbl_Word3;
        private System.Windows.Forms.Label lbl_Word4;
        private System.Windows.Forms.Label lbl_Word5;
        private System.Windows.Forms.TextBox tBox_Kata1;
        private System.Windows.Forms.TextBox tBox_Kata2;
        private System.Windows.Forms.TextBox tBox_Kata3;
        private System.Windows.Forms.TextBox tBox_Kata4;
        private System.Windows.Forms.TextBox tBox_Kata5;
        private System.Windows.Forms.Button btn_Play;
    }
}