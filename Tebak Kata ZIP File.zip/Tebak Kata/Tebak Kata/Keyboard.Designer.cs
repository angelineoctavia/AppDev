﻿namespace Tebak_Kata
{
    partial class Keyboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_M = new System.Windows.Forms.Button();
            this.btn_N = new System.Windows.Forms.Button();
            this.btn_B = new System.Windows.Forms.Button();
            this.btn_V = new System.Windows.Forms.Button();
            this.btn_C = new System.Windows.Forms.Button();
            this.btn_X = new System.Windows.Forms.Button();
            this.btn_Z = new System.Windows.Forms.Button();
            this.btn_L = new System.Windows.Forms.Button();
            this.btn_K = new System.Windows.Forms.Button();
            this.btn_J = new System.Windows.Forms.Button();
            this.btn_H = new System.Windows.Forms.Button();
            this.btn_G = new System.Windows.Forms.Button();
            this.btn_F = new System.Windows.Forms.Button();
            this.btn_D = new System.Windows.Forms.Button();
            this.btn_S = new System.Windows.Forms.Button();
            this.btn_A = new System.Windows.Forms.Button();
            this.btn_P = new System.Windows.Forms.Button();
            this.btn_O = new System.Windows.Forms.Button();
            this.btn_I = new System.Windows.Forms.Button();
            this.btn_U = new System.Windows.Forms.Button();
            this.btn_Y = new System.Windows.Forms.Button();
            this.btn_T = new System.Windows.Forms.Button();
            this.btn_R = new System.Windows.Forms.Button();
            this.btn_E = new System.Windows.Forms.Button();
            this.btn_W = new System.Windows.Forms.Button();
            this.btn_Q = new System.Windows.Forms.Button();
            this.lbl_Blank1 = new System.Windows.Forms.Label();
            this.lbl_Blank2 = new System.Windows.Forms.Label();
            this.lbl_Blank3 = new System.Windows.Forms.Label();
            this.lbl_Blank4 = new System.Windows.Forms.Label();
            this.lbl_Blank5 = new System.Windows.Forms.Label();
            this.lbl_Kata = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_M
            // 
            this.btn_M.Location = new System.Drawing.Point(1012, 428);
            this.btn_M.Name = "btn_M";
            this.btn_M.Size = new System.Drawing.Size(92, 87);
            this.btn_M.TabIndex = 51;
            this.btn_M.Text = "M";
            this.btn_M.UseVisualStyleBackColor = true;
            this.btn_M.Click += new System.EventHandler(this.btn_M_Click);
            // 
            // btn_N
            // 
            this.btn_N.Location = new System.Drawing.Point(891, 428);
            this.btn_N.Name = "btn_N";
            this.btn_N.Size = new System.Drawing.Size(92, 87);
            this.btn_N.TabIndex = 50;
            this.btn_N.Text = "N";
            this.btn_N.UseVisualStyleBackColor = true;
            this.btn_N.Click += new System.EventHandler(this.btn_N_Click);
            // 
            // btn_B
            // 
            this.btn_B.Location = new System.Drawing.Point(767, 428);
            this.btn_B.Name = "btn_B";
            this.btn_B.Size = new System.Drawing.Size(92, 87);
            this.btn_B.TabIndex = 49;
            this.btn_B.Text = "B";
            this.btn_B.UseVisualStyleBackColor = true;
            this.btn_B.Click += new System.EventHandler(this.btn_B_Click);
            // 
            // btn_V
            // 
            this.btn_V.Location = new System.Drawing.Point(645, 428);
            this.btn_V.Name = "btn_V";
            this.btn_V.Size = new System.Drawing.Size(92, 87);
            this.btn_V.TabIndex = 48;
            this.btn_V.Text = "V";
            this.btn_V.UseVisualStyleBackColor = true;
            this.btn_V.Click += new System.EventHandler(this.btn_V_Click);
            // 
            // btn_C
            // 
            this.btn_C.Location = new System.Drawing.Point(528, 428);
            this.btn_C.Name = "btn_C";
            this.btn_C.Size = new System.Drawing.Size(92, 87);
            this.btn_C.TabIndex = 47;
            this.btn_C.Text = "C";
            this.btn_C.UseVisualStyleBackColor = true;
            this.btn_C.Click += new System.EventHandler(this.btn_C_Click);
            // 
            // btn_X
            // 
            this.btn_X.Location = new System.Drawing.Point(411, 428);
            this.btn_X.Name = "btn_X";
            this.btn_X.Size = new System.Drawing.Size(92, 87);
            this.btn_X.TabIndex = 46;
            this.btn_X.Text = "X";
            this.btn_X.UseVisualStyleBackColor = true;
            this.btn_X.Click += new System.EventHandler(this.btn_X_Click);
            // 
            // btn_Z
            // 
            this.btn_Z.Location = new System.Drawing.Point(286, 428);
            this.btn_Z.Name = "btn_Z";
            this.btn_Z.Size = new System.Drawing.Size(92, 87);
            this.btn_Z.TabIndex = 45;
            this.btn_Z.Text = "Z";
            this.btn_Z.UseVisualStyleBackColor = true;
            this.btn_Z.Click += new System.EventHandler(this.btn_Z_Click);
            // 
            // btn_L
            // 
            this.btn_L.Location = new System.Drawing.Point(1126, 318);
            this.btn_L.Name = "btn_L";
            this.btn_L.Size = new System.Drawing.Size(92, 87);
            this.btn_L.TabIndex = 44;
            this.btn_L.Text = "L";
            this.btn_L.UseVisualStyleBackColor = true;
            this.btn_L.Click += new System.EventHandler(this.btn_L_Click);
            // 
            // btn_K
            // 
            this.btn_K.Location = new System.Drawing.Point(1000, 318);
            this.btn_K.Name = "btn_K";
            this.btn_K.Size = new System.Drawing.Size(92, 87);
            this.btn_K.TabIndex = 43;
            this.btn_K.Text = "K";
            this.btn_K.UseVisualStyleBackColor = true;
            this.btn_K.Click += new System.EventHandler(this.btn_K_Click);
            // 
            // btn_J
            // 
            this.btn_J.Location = new System.Drawing.Point(876, 318);
            this.btn_J.Name = "btn_J";
            this.btn_J.Size = new System.Drawing.Size(92, 87);
            this.btn_J.TabIndex = 42;
            this.btn_J.Text = "J";
            this.btn_J.UseVisualStyleBackColor = true;
            this.btn_J.Click += new System.EventHandler(this.btn_J_Click);
            // 
            // btn_H
            // 
            this.btn_H.Location = new System.Drawing.Point(756, 318);
            this.btn_H.Name = "btn_H";
            this.btn_H.Size = new System.Drawing.Size(92, 87);
            this.btn_H.TabIndex = 41;
            this.btn_H.Text = "H";
            this.btn_H.UseVisualStyleBackColor = true;
            this.btn_H.Click += new System.EventHandler(this.btn_H_Click);
            // 
            // btn_G
            // 
            this.btn_G.Location = new System.Drawing.Point(635, 318);
            this.btn_G.Name = "btn_G";
            this.btn_G.Size = new System.Drawing.Size(92, 87);
            this.btn_G.TabIndex = 40;
            this.btn_G.Text = "G";
            this.btn_G.UseVisualStyleBackColor = true;
            this.btn_G.Click += new System.EventHandler(this.btn_G_Click);
            // 
            // btn_F
            // 
            this.btn_F.Location = new System.Drawing.Point(518, 318);
            this.btn_F.Name = "btn_F";
            this.btn_F.Size = new System.Drawing.Size(92, 87);
            this.btn_F.TabIndex = 39;
            this.btn_F.Text = "F";
            this.btn_F.UseVisualStyleBackColor = true;
            this.btn_F.Click += new System.EventHandler(this.btn_F_Click);
            // 
            // btn_D
            // 
            this.btn_D.Location = new System.Drawing.Point(397, 318);
            this.btn_D.Name = "btn_D";
            this.btn_D.Size = new System.Drawing.Size(92, 87);
            this.btn_D.TabIndex = 38;
            this.btn_D.Text = "D";
            this.btn_D.UseVisualStyleBackColor = true;
            this.btn_D.Click += new System.EventHandler(this.btn_D_Click);
            // 
            // btn_S
            // 
            this.btn_S.Location = new System.Drawing.Point(274, 318);
            this.btn_S.Name = "btn_S";
            this.btn_S.Size = new System.Drawing.Size(92, 87);
            this.btn_S.TabIndex = 37;
            this.btn_S.Text = "S";
            this.btn_S.UseVisualStyleBackColor = true;
            this.btn_S.Click += new System.EventHandler(this.btn_S_Click);
            // 
            // btn_A
            // 
            this.btn_A.Location = new System.Drawing.Point(155, 318);
            this.btn_A.Name = "btn_A";
            this.btn_A.Size = new System.Drawing.Size(92, 87);
            this.btn_A.TabIndex = 36;
            this.btn_A.Text = "A";
            this.btn_A.UseVisualStyleBackColor = true;
            this.btn_A.Click += new System.EventHandler(this.btn_A_Click);
            // 
            // btn_P
            // 
            this.btn_P.Location = new System.Drawing.Point(1192, 211);
            this.btn_P.Name = "btn_P";
            this.btn_P.Size = new System.Drawing.Size(92, 87);
            this.btn_P.TabIndex = 35;
            this.btn_P.Text = "P";
            this.btn_P.UseVisualStyleBackColor = true;
            this.btn_P.Click += new System.EventHandler(this.btn_P_Click);
            // 
            // btn_O
            // 
            this.btn_O.Location = new System.Drawing.Point(1073, 211);
            this.btn_O.Name = "btn_O";
            this.btn_O.Size = new System.Drawing.Size(92, 87);
            this.btn_O.TabIndex = 34;
            this.btn_O.Text = "O";
            this.btn_O.UseVisualStyleBackColor = true;
            this.btn_O.Click += new System.EventHandler(this.btn_O_Click);
            // 
            // btn_I
            // 
            this.btn_I.Location = new System.Drawing.Point(950, 211);
            this.btn_I.Name = "btn_I";
            this.btn_I.Size = new System.Drawing.Size(92, 87);
            this.btn_I.TabIndex = 33;
            this.btn_I.Text = "I";
            this.btn_I.UseVisualStyleBackColor = true;
            this.btn_I.Click += new System.EventHandler(this.btn_I_Click);
            // 
            // btn_U
            // 
            this.btn_U.Location = new System.Drawing.Point(830, 211);
            this.btn_U.Name = "btn_U";
            this.btn_U.Size = new System.Drawing.Size(92, 87);
            this.btn_U.TabIndex = 32;
            this.btn_U.Text = "U";
            this.btn_U.UseVisualStyleBackColor = true;
            this.btn_U.Click += new System.EventHandler(this.btn_U_Click);
            // 
            // btn_Y
            // 
            this.btn_Y.Location = new System.Drawing.Point(711, 211);
            this.btn_Y.Name = "btn_Y";
            this.btn_Y.Size = new System.Drawing.Size(92, 87);
            this.btn_Y.TabIndex = 31;
            this.btn_Y.Text = "Y";
            this.btn_Y.UseVisualStyleBackColor = true;
            this.btn_Y.Click += new System.EventHandler(this.btn_Y_Click);
            // 
            // btn_T
            // 
            this.btn_T.Location = new System.Drawing.Point(590, 211);
            this.btn_T.Name = "btn_T";
            this.btn_T.Size = new System.Drawing.Size(92, 87);
            this.btn_T.TabIndex = 30;
            this.btn_T.Text = "T";
            this.btn_T.UseVisualStyleBackColor = true;
            this.btn_T.Click += new System.EventHandler(this.btn_T_Click);
            // 
            // btn_R
            // 
            this.btn_R.Location = new System.Drawing.Point(469, 211);
            this.btn_R.Name = "btn_R";
            this.btn_R.Size = new System.Drawing.Size(92, 87);
            this.btn_R.TabIndex = 29;
            this.btn_R.Text = "R";
            this.btn_R.UseVisualStyleBackColor = true;
            this.btn_R.Click += new System.EventHandler(this.btn_R_Click);
            // 
            // btn_E
            // 
            this.btn_E.Location = new System.Drawing.Point(352, 211);
            this.btn_E.Name = "btn_E";
            this.btn_E.Size = new System.Drawing.Size(92, 87);
            this.btn_E.TabIndex = 28;
            this.btn_E.Text = "E";
            this.btn_E.UseVisualStyleBackColor = true;
            this.btn_E.Click += new System.EventHandler(this.btn_E_Click);
            // 
            // btn_W
            // 
            this.btn_W.Location = new System.Drawing.Point(229, 211);
            this.btn_W.Name = "btn_W";
            this.btn_W.Size = new System.Drawing.Size(92, 87);
            this.btn_W.TabIndex = 27;
            this.btn_W.Text = "W";
            this.btn_W.UseVisualStyleBackColor = true;
            this.btn_W.Click += new System.EventHandler(this.btn_W_Click);
            // 
            // btn_Q
            // 
            this.btn_Q.Location = new System.Drawing.Point(110, 211);
            this.btn_Q.Name = "btn_Q";
            this.btn_Q.Size = new System.Drawing.Size(92, 87);
            this.btn_Q.TabIndex = 26;
            this.btn_Q.Text = "Q";
            this.btn_Q.UseVisualStyleBackColor = true;
            this.btn_Q.Click += new System.EventHandler(this.btn_Q_Click);
            // 
            // lbl_Blank1
            // 
            this.lbl_Blank1.AutoSize = true;
            this.lbl_Blank1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Blank1.Location = new System.Drawing.Point(456, 77);
            this.lbl_Blank1.Name = "lbl_Blank1";
            this.lbl_Blank1.Size = new System.Drawing.Size(67, 73);
            this.lbl_Blank1.TabIndex = 52;
            this.lbl_Blank1.Text = "_";
            // 
            // lbl_Blank2
            // 
            this.lbl_Blank2.AutoSize = true;
            this.lbl_Blank2.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Blank2.Location = new System.Drawing.Point(553, 77);
            this.lbl_Blank2.Name = "lbl_Blank2";
            this.lbl_Blank2.Size = new System.Drawing.Size(67, 73);
            this.lbl_Blank2.TabIndex = 53;
            this.lbl_Blank2.Text = "_";
            // 
            // lbl_Blank3
            // 
            this.lbl_Blank3.AutoSize = true;
            this.lbl_Blank3.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Blank3.Location = new System.Drawing.Point(650, 77);
            this.lbl_Blank3.Name = "lbl_Blank3";
            this.lbl_Blank3.Size = new System.Drawing.Size(67, 73);
            this.lbl_Blank3.TabIndex = 54;
            this.lbl_Blank3.Text = "_";
            // 
            // lbl_Blank4
            // 
            this.lbl_Blank4.AutoSize = true;
            this.lbl_Blank4.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Blank4.Location = new System.Drawing.Point(743, 77);
            this.lbl_Blank4.Name = "lbl_Blank4";
            this.lbl_Blank4.Size = new System.Drawing.Size(67, 73);
            this.lbl_Blank4.TabIndex = 55;
            this.lbl_Blank4.Text = "_";
            // 
            // lbl_Blank5
            // 
            this.lbl_Blank5.AutoSize = true;
            this.lbl_Blank5.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Blank5.Location = new System.Drawing.Point(837, 77);
            this.lbl_Blank5.Name = "lbl_Blank5";
            this.lbl_Blank5.Size = new System.Drawing.Size(67, 73);
            this.lbl_Blank5.TabIndex = 56;
            this.lbl_Blank5.Text = "_";
            // 
            // lbl_Kata
            // 
            this.lbl_Kata.AutoSize = true;
            this.lbl_Kata.Location = new System.Drawing.Point(1058, 107);
            this.lbl_Kata.Name = "lbl_Kata";
            this.lbl_Kata.Size = new System.Drawing.Size(56, 25);
            this.lbl_Kata.TabIndex = 57;
            this.lbl_Kata.Text = "Kata";
            // 
            // Keyboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1395, 727);
            this.Controls.Add(this.lbl_Kata);
            this.Controls.Add(this.lbl_Blank5);
            this.Controls.Add(this.lbl_Blank4);
            this.Controls.Add(this.lbl_Blank3);
            this.Controls.Add(this.lbl_Blank2);
            this.Controls.Add(this.lbl_Blank1);
            this.Controls.Add(this.btn_M);
            this.Controls.Add(this.btn_N);
            this.Controls.Add(this.btn_B);
            this.Controls.Add(this.btn_V);
            this.Controls.Add(this.btn_C);
            this.Controls.Add(this.btn_X);
            this.Controls.Add(this.btn_Z);
            this.Controls.Add(this.btn_L);
            this.Controls.Add(this.btn_K);
            this.Controls.Add(this.btn_J);
            this.Controls.Add(this.btn_H);
            this.Controls.Add(this.btn_G);
            this.Controls.Add(this.btn_F);
            this.Controls.Add(this.btn_D);
            this.Controls.Add(this.btn_S);
            this.Controls.Add(this.btn_A);
            this.Controls.Add(this.btn_P);
            this.Controls.Add(this.btn_O);
            this.Controls.Add(this.btn_I);
            this.Controls.Add(this.btn_U);
            this.Controls.Add(this.btn_Y);
            this.Controls.Add(this.btn_T);
            this.Controls.Add(this.btn_R);
            this.Controls.Add(this.btn_E);
            this.Controls.Add(this.btn_W);
            this.Controls.Add(this.btn_Q);
            this.Name = "Keyboard";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.menyimpan_kata);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_M;
        private System.Windows.Forms.Button btn_N;
        private System.Windows.Forms.Button btn_B;
        private System.Windows.Forms.Button btn_V;
        private System.Windows.Forms.Button btn_C;
        private System.Windows.Forms.Button btn_X;
        private System.Windows.Forms.Button btn_Z;
        private System.Windows.Forms.Button btn_L;
        private System.Windows.Forms.Button btn_K;
        private System.Windows.Forms.Button btn_J;
        private System.Windows.Forms.Button btn_H;
        private System.Windows.Forms.Button btn_G;
        private System.Windows.Forms.Button btn_F;
        private System.Windows.Forms.Button btn_D;
        private System.Windows.Forms.Button btn_S;
        private System.Windows.Forms.Button btn_A;
        private System.Windows.Forms.Button btn_P;
        private System.Windows.Forms.Button btn_O;
        private System.Windows.Forms.Button btn_I;
        private System.Windows.Forms.Button btn_U;
        private System.Windows.Forms.Button btn_Y;
        private System.Windows.Forms.Button btn_T;
        private System.Windows.Forms.Button btn_R;
        private System.Windows.Forms.Button btn_E;
        private System.Windows.Forms.Button btn_W;
        private System.Windows.Forms.Button btn_Q;
        private System.Windows.Forms.Label lbl_Blank1;
        private System.Windows.Forms.Label lbl_Blank2;
        private System.Windows.Forms.Label lbl_Blank3;
        private System.Windows.Forms.Label lbl_Blank4;
        private System.Windows.Forms.Label lbl_Blank5;
        private System.Windows.Forms.Label lbl_Kata;
    }
}