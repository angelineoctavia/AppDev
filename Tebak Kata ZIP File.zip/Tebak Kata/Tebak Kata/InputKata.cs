﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Tebak_Kata
{
    public partial class InputKata : Form
    {
        public static string katapertama;
        public static string katakedua;
        public static string kataketiga;
        public static string katakeempat;
        public static string katakelima;

        public InputKata()
        {
            InitializeComponent();
        }

        int kata = 0;

        private void btn_Play_Click(object sender, EventArgs e)
        {
            int countKata1 = 0;
            int countKata2 = 0;
            int countKata3 = 0;
            int countKata4 = 0;
            int countKata5 = 0;
            
            countKata1 = Convert.ToInt32(tBox_Kata1.Text.Length);
            countKata2 = Convert.ToInt32(tBox_Kata2.Text.Length);
            countKata3 = Convert.ToInt32(tBox_Kata3.Text.Length);
            countKata4 = Convert.ToInt32(tBox_Kata4.Text.Length);
            countKata5 = Convert.ToInt32(tBox_Kata5.Text.Length);

            katapertama = tBox_Kata1.Text.ToUpper();
            katakedua = tBox_Kata2.Text.ToUpper();
            kataketiga = tBox_Kata3.Text.ToUpper();
            katakeempat = tBox_Kata4.Text.ToUpper();
            katakelima = tBox_Kata5.Text.ToUpper();

            if (countKata1 != 5 || countKata2 != 5 || countKata3 != 5 || countKata4 != 5 || countKata5 != 5)
            {
                MessageBox.Show("There's still an error");
            }
            else if (tBox_Kata1.Text == tBox_Kata2.Text || tBox_Kata1.Text == tBox_Kata3.Text || tBox_Kata1.Text == tBox_Kata4.Text ||
               tBox_Kata1.Text == tBox_Kata5.Text || tBox_Kata2.Text == tBox_Kata3.Text || tBox_Kata2.Text == tBox_Kata4.Text ||
               tBox_Kata2.Text == tBox_Kata5.Text || tBox_Kata3.Text == tBox_Kata4.Text || tBox_Kata3.Text == tBox_Kata5.Text ||
               tBox_Kata4.Text == tBox_Kata5.Text)
            {
                MessageBox.Show("There's still an error");
            }
            else
            {
                MessageBox.Show("Let's Play!");
                Keyboard keyboard = new Keyboard();
                keyboard.Show();
                this.Hide();
            }
        }
    }
}
