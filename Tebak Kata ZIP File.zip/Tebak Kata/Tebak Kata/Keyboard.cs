﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tebak_Kata
{
    public partial class Keyboard : Form
    {
        public string hurufSekarang;
        string[] jawaban = new string[5];
        public Keyboard()
        {
            InitializeComponent();
        }

        Random randomkata = new Random();
        List<string> menyimpankata = new List<string>()
        { InputKata.katapertama, InputKata.katakedua, InputKata.kataketiga, InputKata.katakeempat, InputKata.katakelima };

        private void menyimpan_kata(object sender, EventArgs e)
        {
            kata_Acak(menyimpankata);
        }

        void kata_Acak(List<string> daftarkata)
        {
            int index = randomkata.Next(daftarkata.Count);
            string kataAcak = daftarkata[index];

            lbl_Kata.Text = kataAcak;
        }

        private void ManggilDiButton(string huruf)
        {
            List<int> posisiHurufYangTertebak = new List<int>();
            for (int i = 0; i < jawaban.Length; i++) 
            {
                if (huruf == jawaban[i])
                {
                    posisiHurufYangTertebak.Add(i);
                }
            }
            MunculinYangBenar(posisiHurufYangTertebak);
        }

        private void MunculinYangBenar(List<int> posisiGuessHuruf)
        {
        }


        private void btn_Q_Click(object sender, EventArgs e)
        {
            ManggilDiButton("Q");
        }

        private void btn_W_Click(object sender, EventArgs e)
        {
            ManggilDiButton("W");
        }

        private void btn_E_Click(object sender, EventArgs e)
        {
            ManggilDiButton("E");
        }

        private void btn_R_Click(object sender, EventArgs e)
        {
            ManggilDiButton("R");
        }

        private void btn_T_Click(object sender, EventArgs e)
        {
            ManggilDiButton("T");
        }

        private void btn_Y_Click(object sender, EventArgs e)
        {
            ManggilDiButton("Y");
        }

        private void btn_U_Click(object sender, EventArgs e)
        {
            ManggilDiButton("U");
        }

        private void btn_I_Click(object sender, EventArgs e)
        {
            ManggilDiButton("I");
        }

        private void btn_O_Click(object sender, EventArgs e)
        {
            ManggilDiButton("O");
        }

        private void btn_P_Click(object sender, EventArgs e)
        {
            ManggilDiButton("P");
        }

        private void btn_A_Click(object sender, EventArgs e)
        {
            ManggilDiButton("A");
        }

        private void btn_S_Click(object sender, EventArgs e)
        {
            ManggilDiButton("S");
        }

        private void btn_D_Click(object sender, EventArgs e)
        {
            ManggilDiButton("D");
        }

        private void btn_F_Click(object sender, EventArgs e)
        {
            ManggilDiButton("F");
        }

        private void btn_G_Click(object sender, EventArgs e)
        {
            ManggilDiButton("G");
        }

        private void btn_H_Click(object sender, EventArgs e)
        {
            ManggilDiButton("H");
        }

        private void btn_J_Click(object sender, EventArgs e)
        {
            ManggilDiButton("J");
        }

        private void btn_K_Click(object sender, EventArgs e)
        {
            ManggilDiButton("K");
        }

        private void btn_L_Click(object sender, EventArgs e)
        {
            ManggilDiButton("L");
        }

        private void btn_Z_Click(object sender, EventArgs e)
        {
            ManggilDiButton("Z");
        }

        private void btn_X_Click(object sender, EventArgs e)
        {
            ManggilDiButton("X");
        }

        private void btn_C_Click(object sender, EventArgs e)
        {
            ManggilDiButton("C");
        }

        private void btn_V_Click(object sender, EventArgs e)
        {
            ManggilDiButton("V");
        }

        private void btn_B_Click(object sender, EventArgs e)
        {
            ManggilDiButton("B");
        }

        private void btn_N_Click(object sender, EventArgs e)
        {
            ManggilDiButton("N");
        }

        private void btn_M_Click(object sender, EventArgs e)
        {
            ManggilDiButton("M");
        }
    }
}
